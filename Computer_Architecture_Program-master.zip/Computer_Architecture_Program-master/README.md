# Computer_Architecture_Program
Created during my Computer Architecture and design class.  Looking forward to finishing it.

The program is suppose to build a computer based on the Von Neumann Architecture.  The program currently
just takes in the values for a processor and memory(RAM).  Then creates a computer object with this value.  Written into the code are
classes representing the System bus, the signals sent on the bus, the cycle of the CPU(fetch, decode, execute), and the instructions
for the processor.  Currently these just send null signals and values.
