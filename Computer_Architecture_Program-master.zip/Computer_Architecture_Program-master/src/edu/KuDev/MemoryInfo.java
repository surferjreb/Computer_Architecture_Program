package edu.KuDev;

import edu.KuDev.architexture.Memory;

public class MemoryInfo {
    public int size;
    public String brand;
    public int transferRate;
    public int Quantity;

    public MemoryInfo(int size, String brand, int transferRate, int quantity) {
        this.size = size;
        this.brand = brand;
        this.transferRate = transferRate;
        Quantity = quantity;
    }
}
