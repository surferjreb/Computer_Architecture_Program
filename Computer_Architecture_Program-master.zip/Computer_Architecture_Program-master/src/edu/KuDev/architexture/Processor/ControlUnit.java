package edu.KuDev.architexture.Processor;

public class ControlUnit {
    private String name;

    public ControlUnit(String name){

        this.name = name;
    }

    @Override
    public String toString() {
        return "ControlUnit name= " + name;
    }
}
