package edu.KuDev.architexture.Processor.ISA;

public class Add extends Instruction{
    public Add(byte[] data) {
        super(data);
    }
}
