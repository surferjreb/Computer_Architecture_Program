package edu.KuDev.architexture.Processor;

public class ALU{
    private String name;

    public ALU(String name){
        this.name = name;
    }

    @Override
    public String toString() {
        return "ALU{" +
                "name='" + name + '\'' +
                '}';
    }


}
