package edu.KuDev.architexture.Processor;

import edu.KuDev.architexture.Messaging.Subscriber;

public interface iProcessor extends Subscriber {
}
